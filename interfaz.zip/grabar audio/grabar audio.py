import pyaudio
import wave
import os

# configura para poder grabar el audio para que grabe 5 segundos
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 44100
CHUNK = 1024
RECORD_SECONDS = 5

# Crea la carpeta para guardar nuestras grabaciones, si no existe, si ya existe no creara un duplicado de la carpeta
if not os.path.exists('grabaciones'):
    os.makedirs('grabaciones')

# si es que existe una grabacion con un nombre ya hecho, le suma un numero para que pueda guardar la nueva
serie = 1
for filename in os.listdir('grabaciones'):
    if filename.startswith('grabacion_'):
        numero_serie = int(filename.split('_')[1].split('.')[0])
        if numero_serie >= serie:
            serie = numero_serie + 1

# Genera el nombre de la grabacion
filename = f'grabaciones/grabacion_{serie}.wav'

# inicia el objeto audio
audio = pyaudio.PyAudio()

# Inicia la grabación
stream = audio.open(format=FORMAT, channels=CHANNELS,
                    rate=RATE, input=True,
                    frames_per_buffer=CHUNK)

print("Grabando")
frames = []
for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
    data = stream.read(CHUNK)
    frames.append(data)
print("Grabación completada")

# Detiene la grabación y cierra el objeto PyAudio
stream.stop_stream()
stream.close()
audio.terminate()

# Guarda el archivo de audio en disco
wf = wave.open(filename, 'wb')
wf.setnchannels(CHANNELS)
wf.setsampwidth(audio.get_sample_size(FORMAT))
wf.setframerate(RATE)
wf.writeframes(b''.join(frames))
wf.close()

print(f"Grabación guardada")